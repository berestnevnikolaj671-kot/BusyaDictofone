rootProject.name = "BusyaDictaphone"
include(":app")